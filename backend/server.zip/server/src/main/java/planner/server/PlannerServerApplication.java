package planner.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlannerServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlannerServerApplication.class, args);
	}

}
