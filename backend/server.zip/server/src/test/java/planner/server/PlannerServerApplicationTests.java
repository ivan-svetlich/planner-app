package planner.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlannerServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
